<?php
require __DIR__ . '/../../../backside/api/get_posts.php';
require_once __DIR__ . '/../inc/config.php';
header('Content-Type: application/json; charset=utf-8');
